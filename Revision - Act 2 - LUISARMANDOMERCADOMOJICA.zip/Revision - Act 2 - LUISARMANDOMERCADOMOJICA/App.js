import './App.css';

function Tabla() {
  return (
    <div>
      <table border="1">
        <thead>
          <tr>
            <th>Identificador (ID) de la Historia</th>
            <th>Enunciado de la Historia</th>
            <th>Alias</th>
            <th>Estado</th>
            <th>Dimensión/ Esfuerzo</th>
            <th>Interacción (Sprint)</th>
            <th>Prioridad</th>
            <th>Comentarios</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>01</td>
            <td>Reunión con las personas clave del producto ademas, de llegar a los acuerdos y estipular los requerimientos del sitio web.</td>
            <td>INI</td>
            <td>En proceso</td>
            <td>3 Días</td>
            <td>SPRINT 1</td>
            <td>ALTA</td>
            <td>Llegar a acuerdos con los encargados de proyecto</td>
          </tr>
          <tr>
            <td>02</td>
            <td>Creacion del sitio web, sus funcionalidadees, y testeo del sitio para correccion de bugs</td>
            <td>DRR</td>
            <td>En proceso</td>
            <td>8 Días</td>
            <td>SPRINT 2</td>
            <td>BAJA</td>
            <td>Delegar responsabilidades de las partes del producto</td>
          </tr>
          <tr>
            <td>03</td>
            <td>Subida del proyecto a la web y creacion del grupo de whatsap ademas de exponer a los interesados el proyecto para su correcion y valoracion.</td>
            <td>END</td>
            <td>Planificado</td>
            <td>7 Días</td>
            <td>SPRINT 3</td>
            <td>ALTA</td>
            <td>Presentar el proyecto y corregirt los datos que se an pedido.</td>
          </tr>
        </tbody>
      </table>

    </div>
  );
}

export default Tabla;