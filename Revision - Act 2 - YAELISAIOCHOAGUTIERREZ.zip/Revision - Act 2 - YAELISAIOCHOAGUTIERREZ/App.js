import React from 'react';
import './StoryTable.css';

function StoryTable() {
  return (
    <table className="story-table">
      <thead>
        <tr>
          <th>Identificador (ID) de la Historia</th>
          <th>Enunciado de la Historia</th>
          <th>Alias</th>
          <th>Estado</th>
          <th>Dimensión/ Esfuerzo</th>
          <th>Interacción (Sprint)</th>
          <th>Prioridad</th>
          <th>Comentarios</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>CE-001</td>
          <td>Se elaborará una página web, que solvente los problemas de comunicación, mejorando la conectividad entre los vecinos y los dueños de la Residencia, sirviendo a su vez de puiblicidad para la Residencia.</td>
          <td>PWB</td>
          <td>En proceso</td>
          <td>10 días</td>
          <td>1</td>
          <td>Alta</td>
          <td>Enfoque en UI UX</td>
        </tr>
        <tr>
          <td>CE-002</td>
          <td>Se elaborará un grupo de WhatsApp para conectar a los vecinos, y servir como medio de comunicacion para dar cualquier aviso importante. Se elaborarán reglas de comunicacion para evitar problemas entre vecinos.</td>
          <td>Wa</td>
          <td>En proceso</td>
          <td>6 días</td>
          <td>2</td>
          <td>Media</td>
          <td>Roles</td>
        </tr>
        <tr>
          <td>CE-003</td>
          <td>Se elaborará una base de datos donde almacenar los datos de la Residencia, de esta forma trabajaremos en evitar adeudos y malos entendidos entre vecinos. Dicha base de datos será pública para los vecinos.</td>
          <td>BDB</td>
          <td>Planificada</td>
          <td>14 días</td>
          <td>3</td>
          <td>Media</td>
          <td>MySQL</td>
        </tr>
      </tbody>
    </table>
  );
}

export default StoryTable;
